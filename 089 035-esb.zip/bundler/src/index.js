import message from './message';

console.log(message);
