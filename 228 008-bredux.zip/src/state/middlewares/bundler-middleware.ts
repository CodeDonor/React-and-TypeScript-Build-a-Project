import { Middleware } from './middleware';
import { ActionType } from '../action-types';

export const bundlerMiddleware: Middleware = (store) => (next) => (
  action
) => {};
